python convnet.py --layer-def=./gc-layers/layers5.gc.cfg --layer-params=./gc-layers/params2.gc.cfg --data-provider=dummy-cn-192 --check-grads=1
